var SweetModal = require('./components/SweetModal.vue')
var SweetModalTab = require('./components/SweetModalTab.vue')

module.exports = {
	SweetModal: SweetModal,
	SweetModalTab: SweetModalTab
}